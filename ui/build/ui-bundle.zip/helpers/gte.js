'use strict'

module.exports = (a, b) => {
  if (a >= b) {
    return true
  }
  else {
    return false
  }
}